/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createSupplierEntity = /* GraphQL */ `
  mutation CreateSupplierEntity(
    $input: CreateSupplierEntityInput!
    $condition: ModelSupplierEntityConditionInput
  ) {
    createSupplierEntity(input: $input, condition: $condition) {
      id
      name
      servicetype
      location
      phone
      email
      overallrating
      createdAt
      updatedAt
    }
  }
`;
export const updateSupplierEntity = /* GraphQL */ `
  mutation UpdateSupplierEntity(
    $input: UpdateSupplierEntityInput!
    $condition: ModelSupplierEntityConditionInput
  ) {
    updateSupplierEntity(input: $input, condition: $condition) {
      id
      name
      servicetype
      location
      phone
      email
      overallrating
      createdAt
      updatedAt
    }
  }
`;
export const deleteSupplierEntity = /* GraphQL */ `
  mutation DeleteSupplierEntity(
    $input: DeleteSupplierEntityInput!
    $condition: ModelSupplierEntityConditionInput
  ) {
    deleteSupplierEntity(input: $input, condition: $condition) {
      id
      name
      servicetype
      location
      phone
      email
      overallrating
      createdAt
      updatedAt
    }
  }
`;
export const createConsumerEntity = /* GraphQL */ `
  mutation CreateConsumerEntity(
    $input: CreateConsumerEntityInput!
    $condition: ModelConsumerEntityConditionInput
  ) {
    createConsumerEntity(input: $input, condition: $condition) {
      id
      name
      email
      phone
      vehicletype
      vehiclemodel
      createdAt
      updatedAt
    }
  }
`;
export const updateConsumerEntity = /* GraphQL */ `
  mutation UpdateConsumerEntity(
    $input: UpdateConsumerEntityInput!
    $condition: ModelConsumerEntityConditionInput
  ) {
    updateConsumerEntity(input: $input, condition: $condition) {
      id
      name
      email
      phone
      vehicletype
      vehiclemodel
      createdAt
      updatedAt
    }
  }
`;
export const deleteConsumerEntity = /* GraphQL */ `
  mutation DeleteConsumerEntity(
    $input: DeleteConsumerEntityInput!
    $condition: ModelConsumerEntityConditionInput
  ) {
    deleteConsumerEntity(input: $input, condition: $condition) {
      id
      name
      email
      phone
      vehicletype
      vehiclemodel
      createdAt
      updatedAt
    }
  }
`;
