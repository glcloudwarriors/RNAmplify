/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateSupplierEntity = /* GraphQL */ `
  subscription OnCreateSupplierEntity {
    onCreateSupplierEntity {
      id
      name
      servicetype
      location
      phone
      email
      overallrating
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateSupplierEntity = /* GraphQL */ `
  subscription OnUpdateSupplierEntity {
    onUpdateSupplierEntity {
      id
      name
      servicetype
      location
      phone
      email
      overallrating
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteSupplierEntity = /* GraphQL */ `
  subscription OnDeleteSupplierEntity {
    onDeleteSupplierEntity {
      id
      name
      servicetype
      location
      phone
      email
      overallrating
      createdAt
      updatedAt
    }
  }
`;
export const onCreateConsumerEntity = /* GraphQL */ `
  subscription OnCreateConsumerEntity {
    onCreateConsumerEntity {
      id
      name
      email
      phone
      vehicletype
      vehiclemodel
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateConsumerEntity = /* GraphQL */ `
  subscription OnUpdateConsumerEntity {
    onUpdateConsumerEntity {
      id
      name
      email
      phone
      vehicletype
      vehiclemodel
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteConsumerEntity = /* GraphQL */ `
  subscription OnDeleteConsumerEntity {
    onDeleteConsumerEntity {
      id
      name
      email
      phone
      vehicletype
      vehiclemodel
      createdAt
      updatedAt
    }
  }
`;
