/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const getSupplierEntity = /* GraphQL */ `
  query GetSupplierEntity($id: ID!) {
    getSupplierEntity(id: $id) {
      id
      name
      servicetype
      location
      phone
      email
      overallrating
      createdAt
      updatedAt
    }
  }
`;
export const listSupplierEntitys = /* GraphQL */ `
  query ListSupplierEntitys(
    $filter: ModelSupplierEntityFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listSupplierEntitys(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        name
        servicetype
        location
        phone
        email
        overallrating
        createdAt
        updatedAt
      }
      nextToken
    }
  }
`;
export const getConsumerEntity = /* GraphQL */ `
  query GetConsumerEntity($id: ID!) {
    getConsumerEntity(id: $id) {
      id
      name
      email
      phone
      vehicletype
      vehiclemodel
      createdAt
      updatedAt
    }
  }
`;
export const listConsumerEntitys = /* GraphQL */ `
  query ListConsumerEntitys(
    $filter: ModelConsumerEntityFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listConsumerEntitys(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        name
        email
        phone
        vehicletype
        vehiclemodel
        createdAt
        updatedAt
      }
      nextToken
    }
  }
`;
