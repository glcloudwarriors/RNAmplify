import React from 'react'
import {View, Text, StyleSheet, ScrollView, ImageBackground, Image} from "react-native"
import {DrawerNavigatorItems} from "react-navigation-drawer"
import {Ionicons} from "@expo/vector-icons"
import DrawerNavigator from 'react-navigation-drawer/lib/typescript/src/navigators/createDrawerNavigator'

export default Sidebar = props => {
    <ScrollView>
        <ImageBackground source={require("c:/Users/mavle/RNAmplify/src/assets/fmvlogo.png")} 
        style={{width: undefined, padding : 16, paddingTop : 48}}>
            
        </ImageBackground>
        <View style={{flex: 1}}>
            <DrawerNavigatorItems {...props} />
        </View>
    </ScrollView>
};