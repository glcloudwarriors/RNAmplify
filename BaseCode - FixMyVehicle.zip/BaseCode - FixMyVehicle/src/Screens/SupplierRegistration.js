import React, { useEffect, useState } from 'react'
import {  View, Text, StyleSheet, TextInput, Button, Image } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator,createAppContainer,StackNavigator } from '@react-navigation/stack';
import { API, graphqlOperation } from 'aws-amplify'
import { listSupplierEntitys } from 'C:/Users/mavle/RNAmplify/src/graphql/queries'
import { createSupplierEntity } from 'C:/Users/mavle/RNAmplify/src/graphql/mutations'
import {  ServiceType } from 'graphql'; 
import logofile from 'C:/Users/mavle/RNAmplify/src/assets/fmvlogo.png';

const initialState = {name: '', location: '', servicetype : {values : 'CAR'}, phone : 0, email : ''}

const SupplierRegistration = () => {
  const [formState, setFormState] = useState(initialState)
  const [suppliers, setSuppliers] = useState([])

  function setInput(key, value) {
    setFormState({ ...formState, [key]: value })
  }


  async function addSupplier() {
    try {
      const supplier = { ...formState }
      setSuppliers([...suppliers, supplier])
      setFormState(initialState)
      await API.graphql(graphqlOperation(createSupplierEntity, {input: supplier}))
    } catch (err) {
      console.log('error registering Supplier:', err)
    }
  }

    return (
                  <View style={styles.container}>

                  <TextInput
                    onChangeText={val => setInput('name', val)}
                    style={styles.input}
                    value={formState.name}
                    placeholder="Name"
                  />
                  <TextInput
                    onChangeText={val => setInput('servicetype', val)}
                    style={styles.input}
                    value={formState.servicetype}
                    placeholder="servicetype"
                  />
                  <TextInput
                    onChangeText={val => setInput('location', val)}
                    style={styles.input}
                    value={formState.location}
                    placeholder="location"
                  />
                  <TextInput
                    onChangeText={val => setInput('phone', val)}
                    style={styles.input}
                    value={formState.phone}
                    placeholder="phone"
                  />
                  <TextInput
                    onChangeText={val => setInput('email', val)}
                    style={styles.input}
                    value={formState.email}
                    placeholder="email"
                  />
                  <Button title="Register" onPress={addSupplier} />
                  {
                    suppliers.map((supplier, index) => (
                      <View key={supplier.id ? supplier.id : index} style={styles.todo}>
                        <Text style={styles.todoName}>{supplier.name}</Text>
                        <Text style={styles.todoName}>{supplier.servicetype}</Text>
                        <Text style={styles.todoName}>{supplier.location}</Text>
                        <Text style={styles.todoName}>{supplier.phone}</Text>
                        <Text style={styles.todoName}>{supplier.email}</Text>
                      </View>
                    ))
                  }
                  </View>
        )
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20},
  todo: {  marginBottom: 15 },
  input: { height: 50, backgroundColor: '#ddd', marginBottom: 10, padding: 8 },
  suppliernamestyle: { fontSize: 18,justifyContent: 'center', color:'dodgerblue',fontSize:25 },
  supplierlocationstyle: { fontSize: 18,justifyContent: 'center', color:'green' },
  todoName: { fontSize: 18 },
  logoContainer: {  right: 1, left : 1},
})

export default SupplierRegistration