import React, {Component} from 'react';
import {View, StyleSheet, Text, Image, Button, TouchableOpacity}  from "react-native";
import  Amplify, {Auth} from 'aws-amplify';
import {Authenticator} from 'aws-amplify-react-native';
import logofile from 'C:/Users/mavle/RNAmplify/src/assets/fmvlogo.png';
import ServiceList from 'C:/Users/mavle/RNAmplify/src/Screens/ServiceList.js';
import SupplierRegistration from 'C:/Users/mavle/RNAmplify/src/Screens/SupplierRegistration.js';

/*export default class App extends React.Component {
   render() {
   */
   function Login(props) {
     const { navigation } = props
       return(
            <View style={styles.container}>
              <View style={styles.logoContainer}>
                <Image source={logofile} />
              </View>
              <Authenticator></Authenticator>
            </View>
        );

   }
/*
}
*/
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'dodgerblue',
  },
  logoContainer: {
    left: 1,
    right: 2,
  },
  welcomestyle: {
    color: 'dodgerblue',
  },
  buttonstyle: {
      backgroundColor: 'orange',
      width: 200
    },
  fullScreenMap: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
   buttonContainer: {
      backgroundColor: '#222',
      borderRadius: 5,
      padding: 10,
      margin: 20
    },
    buttonText: {
      fontSize: 20,
      color: '#fff'
    }
});

export default Login