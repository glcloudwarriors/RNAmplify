import React, { useEffect, useState } from 'react'
import {  View, Text, StyleSheet, TextInput, Button } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator,createAppContainer,StackNavigator } from '@react-navigation/stack';
import { API, graphqlOperation } from 'aws-amplify'
import { listSupplierEntitys } from 'C:/Users/mavle/RNAmplify/src/graphql/queries'

const query = 'query {listSupplierEntitys {items {id name email phone servicetype location}}}'

const initialState = { name: '', location: '' }

const ServiceList = () => {
  const [formState, setFormState] = useState(initialState)
  const [suppliers, setSuppliers] = useState([])

  useEffect(() => {
    fetchSupplierEntities()
  }, [])


  async function fetchSupplierEntities() {
    try {
      const supplierData = await API.graphql(graphqlOperation(listSupplierEntitys))
      const suppliers = supplierData.data.listSupplierEntitys.items
      setSuppliers(suppliers)
    } catch (err) { console.log('error fetching Suppliers') }
  }

    return (
                    <View style={styles.container}>
                    {
                        suppliers.map((supplier,index) => (
                        <View key={supplier.id ? supplier.id : index} style={styles.todo}>
                            <Text style={styles.suppliernamestyle}>{supplier.name}</Text>
                            <Text style={styles.supplierlocationstyle}>{supplier.location}</Text>
                        </View>))
                    }
                    </View>
        )
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20},
  todo: {  marginBottom: 15 },
  input: { height: 50, backgroundColor: '#ddd', marginBottom: 10, padding: 8 },
  suppliernamestyle: { fontSize: 18,justifyContent: 'center', color:'dodgerblue',fontSize:25 },
  supplierlocationstyle: { fontSize: 18,justifyContent: 'center', color:'green' },
})

export default ServiceList