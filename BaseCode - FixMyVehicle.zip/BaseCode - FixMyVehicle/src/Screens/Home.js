import React, {Component} from 'react';
import {View, StyleSheet, Text, Image, Button, TouchableOpacity}  from "react-native";
import  Amplify, {Auth} from 'aws-amplify';
import {Authenticator} from 'aws-amplify-react-native';
import logofile from 'C:/Users/mavle/RNAmplify/src/assets/fmvlogo.png';
import Login from 'C:/Users/mavle/RNAmplify/src/Screens/Login.js';
import ServiceList from 'C:/Users/mavle/RNAmplify/src/Screens/ServiceList.js';
import SupplierRegistration from 'C:/Users/mavle/RNAmplify/src/Screens/SupplierRegistration.js';
import ConsumerRegistration from 'C:/Users/mavle/RNAmplify/src/Screens/ConsumerRegistration.js';

/*export default class App extends React.Component {
   render() {
   */
   function Home(props) {
     const { navigation } = props
       return(

              <View style={styles.container}>
                <TouchableOpacity
                  style={styles.buttonContainer}
                  onPress={() => navigation.navigate(Login)}>
                  <Text style={styles.buttonText}>Login</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.buttonContainer}
                  onPress={() => navigation.navigate(ServiceList)}>
                  <Text style={styles.buttonText}>List Registered Service Providers</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.buttonContainer}
                  onPress={() => navigation.navigate(SupplierRegistration)}>
                  <Text style={styles.buttonText}>Service Provider Registration</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.buttonContainer}
                  onPress={() => navigation.navigate(ConsumerRegistration)}>
                  <Text style={styles.buttonText}>Vehicle Owner Registration</Text>
                </TouchableOpacity>
             </View>
        );
   }
/*
}
*/
const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  logoContainer: {
    left: 1,
    right: 2,
  },
  welcomestyle: {
    color: 'dodgerblue',
  },
  buttonstyle: {
      backgroundColor: 'orange',
      width: 200
    },
  fullScreenMap: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
   buttonContainer: {
      backgroundColor: 'orange',
      borderRadius: 5,
      padding: 10,
      margin: 20
    },
    buttonText: {
      fontSize: 20,
      color: 'blue'
    }
});

export default Home