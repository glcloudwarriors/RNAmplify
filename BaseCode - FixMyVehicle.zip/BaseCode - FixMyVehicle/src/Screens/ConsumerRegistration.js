import React, { useEffect, useState } from 'react'
import {  View, Text, StyleSheet, TextInput, Button, Image } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator,createAppContainer,StackNavigator } from '@react-navigation/stack';
import { API, graphqlOperation } from 'aws-amplify'
import { createConsumerEntity } from 'C:/Users/mavle/RNAmplify/src/graphql/mutations'
import {  ServiceType } from 'graphql';
import logofile from 'C:/Users/mavle/RNAmplify/src/assets/fmvlogo.png';

const initialState = {name: '', email: '', phone : '', vehicletype : {values : 'CAR'}, vehiclemodel : ''}

const ConsumerRegistration = () => {
  const [formState, setFormState] = useState(initialState)
  const [consumers, setConsumers] = useState([])

  function setInput(key, value) {
    setFormState({ ...formState, [key]: value })
  }


  async function addConsumer() {
    try {
      const consumer = { ...formState }
      setConsumers([...consumers, consumer])
      setFormState(initialState)
      await API.graphql(graphqlOperation(createConsumerEntity, {input: consumer}))
    } catch (err) {
      console.log('error registering Consumer:', err)
    }
  }

    return (
                  <View style={styles.container}>

                  <TextInput
                    onChangeText={val => setInput('name', val)}
                    style={styles.input}
                    value={formState.name}
                    placeholder="Name"
                  />
                  <TextInput
                    onChangeText={val => setInput('phone', val)}
                    style={styles.input}
                    value={formState.phone}
                    placeholder="phone"
                  />
                  <TextInput
                    onChangeText={val => setInput('email', val)}
                    style={styles.input}
                    value={formState.email}
                    placeholder="email"
                  />
                  <TextInput
                    onChangeText={val => setInput('vehicletype', val)}
                    style={styles.input}
                    value={formState.vehicletype}
                    placeholder="vehicletype"
                  />
                  <TextInput
                    onChangeText={val => setInput('vehiclemodel', val)}
                    style={styles.input}
                    value={formState.vehiclemodel}
                    placeholder="vehiclemodel"
                  />
                  <Button title="Register" onPress={addConsumer} />
                  {
                    consumers.map((consumer, index) => (
                      <View key={consumer.id ? consumer.id : index} style={styles.todo}>
                        <Text style={styles.todoName}>{consumer.name}</Text>
                        <Text style={styles.todoName}>{consumer.phone}</Text>
                        <Text style={styles.todoName}>{consumer.email}</Text>
                        <Text style={styles.todoName}>{consumer.vehicletype}</Text>
                        <Text style={styles.todoName}>{consumer.vehiclemodel}</Text>
                      </View>
                    ))
                  }
                  </View>
        )
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20},
  todo: {  marginBottom: 15 },
  input: { height: 50, backgroundColor: '#ddd', marginBottom: 10, padding: 8 },
  todoName: { fontSize: 18 },
  logoContainer: {  right: 1, left : 1},
})

export default ConsumerRegistration