/**
 * @format
 */

/*
import React from 'react';
import Screen from 'C:/Users/mavle/RNAmplify/src/Screens/Screens.js';

export const Home = ({navigation}) => <Screen navigation={navigation} name="Home" />
export const ServiceList = ({navigation}) => <Screen navigation={navigation} name="ServiceList" />
export const ConsumerRegistration = ({navigation}) => <Screen navigation={navigation} name="ConsumerRegistration" />
export const ConsumerRaiseRequest = ({navigation}) => <Screen navigation={navigation} name="ConsumerRaiseRequest" />
export const SupplierRegistration = ({navigation}) => <Screen navigation={navigation} name="SupplierRegistration" />
export const SupplierAcceptRequest = ({navigation}) => <Screen navigation={navigation} name="SupplierAcceptRequest" />
export const ViewMap = ({navigation}) => <Screen navigation={navigation} name="ViewMap" />

import {AppRegistry} from 'react-native';
import {name as appName} from './app.json';
AppRegistry.registerComponent(appName, () => Screen);

*/

import {AppRegistry} from 'react-native';
import App from './App';
import {name as appName} from './app.json';

AppRegistry.registerComponent(appName, () => App);
